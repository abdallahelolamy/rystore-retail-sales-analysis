@echo off
chcp 65001 >nul
cd /d "%~dp0"
set PY=python
where python >nul 2>nul || set PY=py
echo Installing / checking libraries (first time only, may take a minute)...
%PY% -m pip install --quiet pandas numpy scipy matplotlib
if errorlevel 1 (
  echo.
  echo Could not install libraries. Make sure Python is installed and "Add Python to PATH" was ticked.
  pause
  exit /b 1
)
%PY% build_report.py
if errorlevel 1 (
  echo.
  echo Something failed - send the message above to Claude.
  pause
  exit /b 1
)
start "" "%~dp0RYStore_Report.html"
echo.
echo Report opened in your browser: RYStore_Report.html
pause
