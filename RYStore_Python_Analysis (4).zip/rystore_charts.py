#!/usr/bin/env python3
"""
RYStore - Evidence charts (one chart per finding of rystore_analysis.py)
Usage:  python rystore_charts.py            -> charts open on screen (close a window to continue)
        python rystore_charts.py --save     -> also save PNGs into ./charts
        python rystore_charts.py --no-show --save   -> only save (no windows)
        python rystore_charts.py path\\to\\data   -> custom data folder
Needs:  pip install pandas numpy scipy matplotlib
"""
import os, sys, warnings
import numpy as np
import pandas as pd
import matplotlib
ARGS = sys.argv[1:]
SAVE = "--save" in ARGS
NOSHOW = "--no-show" in ARGS
if NOSHOW:
    matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import stats

warnings.filterwarnings("ignore")
BASE = os.path.dirname(os.path.abspath(__file__))
_paths = [a for a in ARGS if not a.startswith("--")]
DATA = _paths[0] if _paths else os.path.join(BASE, "data")
OUT = os.path.join(BASE, "charts")
if SAVE:
    os.makedirs(OUT, exist_ok=True)

plt.rcParams.update({"figure.dpi": 130, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.grid": True, "grid.alpha": .25, "font.size": 10, "axes.titleweight": "bold",
                     "axes.titlesize": 12})
C1, C2, C3, GREY = "#2E6F9E", "#E07B39", "#C0392B", "#8A8A8A"

T = {t: pd.read_csv(os.path.join(DATA, f"{t}.csv")) for t in
     ["stores", "suppliers", "promotions", "customers", "products", "employees", "orders", "order_items", "inventory"]}
stores, sup, promo, cust, prod, emp, orders, items, inv = (T[k] for k in
    ["stores", "suppliers", "promotions", "customers", "products", "employees", "orders", "order_items", "inventory"])
orders["order_datetime"] = pd.to_datetime(orders["order_datetime"]); orders["order_date"] = pd.to_datetime(orders["order_date"])
for c in ["start_date", "end_date"]: promo[c] = pd.to_datetime(promo[c])
rev = orders[orders.is_revenue == 1]
ri = (items.merge(orders[["order_id", "order_date", "store_id", "is_revenue"]], on="order_id")
           .merge(prod[["product_id", "product_name", "category", "unit_cost", "supplier_id"]], on="product_id"))
ri = ri[ri.is_revenue == 1].copy()
ri["gp"] = ri.line_net_amount - ri.quantity * ri.unit_cost
NET = rev.net_subtotal.sum()
saved = []

def save(fig, name, note):
    fig.text(0.01, 0.005, note, fontsize=8, color=GREY, ha="left", va="bottom")
    fig.tight_layout(rect=(0, 0.03, 1, 1))
    try:
        fig.canvas.manager.set_window_title(name.replace(".png", ""))
    except Exception:
        pass
    if SAVE:
        fig.savefig(os.path.join(OUT, name)); print("saved", os.path.join(OUT, name))
    saved.append(name)
    if NOSHOW:
        plt.close(fig)


# 1 -- trend: flat revenue, volume-driven -------------------------------------------------
mo = rev.groupby(rev.order_date.dt.to_period("M")).agg(rev=("net_subtotal", "sum"), n=("order_id", "count"))
x = np.arange(len(mo)); lr = stats.linregress(x, mo.rev.values)
fig, ax = plt.subplots(figsize=(9, 4.5))
ax.bar(mo.index.astype(str), mo.rev, color=C1, alpha=.85, label="Net revenue")
ax.plot(mo.index.astype(str), lr.intercept + lr.slope * x, color=C3, lw=2, ls="--",
        label=f"Trend {lr.slope*12/mo.rev.mean():+.1%}/yr (p={lr.pvalue:.2f})")
ax.set_ylim(0, mo.rev.max() * 1.15); ax.set_title("Monthly net revenue: flat, no significant trend")
ax2 = ax.twinx(); ax2.plot(mo.index.astype(str), mo.n, color=C2, marker="o", label="Orders"); ax2.grid(False)
ax2.set_ylim(0, mo.n.max() * 1.3)
h1, l1 = ax.get_legend_handles_labels(); h2, l2 = ax2.get_legend_handles_labels(); ax.legend(h1 + h2, l1 + l2, loc="lower left")
plt.setp(ax.get_xticklabels(), rotation=45, ha="right")
save(fig, "01_monthly_trend.png", f"Revenue tracks order volume (corr {np.corrcoef(mo.rev, mo.n)[0,1]:.2f}), not basket size.")

# 2 -- store revenue vs staff -------------------------------------------------------------
st = rev.groupby("store_id").net_subtotal.sum().rename("rev").reset_index().merge(stores, on="store_id")
rho, p = stats.spearmanr(st.staff_count, st.rev)
fig, ax = plt.subplots(figsize=(8, 5))
fmt_col = {"Large Supermarket": C3, "Medium Supermarket": C1, "Convenience": C2}
for f, g in st.groupby("store_format"):
    ax.scatter(g.staff_count, g.rev, s=140, color=fmt_col[f], label=f, edgecolor="white", zorder=3)
for k, (_, r) in enumerate(st.sort_values("staff_count").iterrows()):
    dy = 12 if k % 2 == 0 else -18
    ax.annotate(r.store_name.replace("RYStore ", ""), (r.staff_count, r.rev), textcoords="offset points",
                xytext=(0, dy), ha="center", fontsize=8)
ax.set_ylim(0, st.rev.max() * 1.15); ax.axhline(st.rev.mean(), color=GREY, ls=":", lw=1)
ax.set_xlabel("Declared staff count"); ax.set_ylabel("Net revenue (year)")
ax.set_title("Same revenue, 3x the staff: headcount is unrelated to sales"); ax.legend()
save(fig, "02_store_staff_vs_revenue.png", f"Spearman rho={rho:.2f}, p={p:.2f}. Store revenue spread only {st.rev.max()/st.rev.min()-1:.0%}.")

# 3 -- category: revenue vs margin --------------------------------------------------------
cat = ri.groupby("category").agg(rev=("line_net_amount", "sum"), gp=("gp", "sum"))
cat["m"] = cat.gp / cat.rev * 100; cat = cat.sort_values("rev")
avg_m = ri.gp.sum() / ri.line_net_amount.sum() * 100
fig, (a, b) = plt.subplots(1, 2, figsize=(11, 5), sharey=True)
a.barh(cat.index, cat.rev, color=C1); a.set_title("Net revenue by category"); a.set_xlabel("Revenue")
cols = [C3 if v < avg_m - 3 else (C1 if v < avg_m + 3 else "#2E8B57") for v in cat.m]
b.barh(cat.index, cat.m, color=cols); b.axvline(avg_m, color="black", ls="--", lw=1); b.set_title("Gross margin %")
b.set_xlabel("Margin %"); b.text(avg_m + .3, -0.6, f"avg {avg_m:.1f}%", fontsize=8)
save(fig, "03_category_revenue_vs_margin.png", "Meat & Fish: biggest revenue, lowest margin. Health & Beauty: best margin, small share.")

# 4 -- promotions: units/day in vs out window ---------------------------------------------
daily = (ri.groupby(["order_date", "category"]).quantity.sum().unstack(fill_value=0)
           .reindex(pd.date_range("2025-01-01", "2025-12-31"), fill_value=0))
rows = []
for _, r in promo.iterrows():
    inw = (daily.index >= r.start_date) & (daily.index <= r.end_date)
    ui, uo = daily.loc[inw, r.category], daily.loc[~inw, r.category]
    rows.append((r.promotion_name, uo.mean(), ui.mean(), (ui.mean() / uo.mean() - 1) * 100,
                 stats.mannwhitneyu(ui, uo).pvalue))
pe = pd.DataFrame(rows, columns=["name", "out", "inn", "lift", "p"])
fig, ax = plt.subplots(figsize=(9, 4.8)); w = .38; i = np.arange(len(pe))
ax.bar(i - w / 2, pe.out, w, color=GREY, label="Outside promo window")
ax.bar(i + w / 2, pe.inn, w, color=[C1 if p < .05 else C2 for p in pe.p], label="Inside promo window")
for k, r in pe.iterrows():
    ax.text(k + w / 2, r.inn + .4, f"{r.lift:+.0f}%\np={r.p:.2f}", ha="center", fontsize=8)
ax.set_xticks(i); ax.set_xticklabels([n.replace(" ", "\n", 1) for n in pe.name], fontsize=8)
ax.set_ylabel("Category units per day"); ax.set_title("Promotions: only one shows a statistically real lift"); ax.legend(loc="upper right")
ax.set_ylim(0, max(pe.inn.max(), pe.out.max()) * 1.3)
save(fig, "04_promotion_lift.png", "Blue = significant (Mann-Whitney p<0.05). Seasonality not controlled -> indicative.")

# 5 -- basket: lift distribution ----------------------------------------------------------
ri_ids = items[items.order_id.isin(rev.order_id)][["order_id", "product_id"]].drop_duplicates()
n_o = ri_ids.order_id.nunique()
pairs = ri_ids.merge(ri_ids, on="order_id"); pairs = pairs[pairs.product_id_x < pairs.product_id_y]
pc = pairs.groupby(["product_id_x", "product_id_y"]).size().rename("t").reset_index()
cnt = ri_ids.groupby("product_id").size()
pc["lift"] = (pc.t / n_o) / ((pc.product_id_x.map(cnt) / n_o) * (pc.product_id_y.map(cnt) / n_o))
fig, ax = plt.subplots(figsize=(8, 4.5))
ax.hist(pc.lift, bins=50, color=C1, alpha=.85); ax.axvline(1, color=C3, ls="--", lw=2, label="Lift = 1 (no affinity)")
ax.axvline(pc.lift.median(), color="black", lw=1, label=f"Median {pc.lift.median():.2f}"); ax.legend()
ax.set_xlabel("Lift of product pair"); ax.set_ylabel("Number of pairs")
ax.set_title(f"All {len(pc):,} product pairs cluster around lift = 1")
save(fig, "05_basket_lift_distribution.png", "Top co-purchase pairs are popular items bought together by chance, not real affinities.")

# 6 -- loyalty: spend by tier with 95% CI -------------------------------------------------
cs = rev.dropna(subset=["customer_id"]).groupby("customer_id").net_subtotal.sum().rename("spend").reset_index().merge(cust, on="customer_id")
tiers = ["Bronze", "Silver", "Gold", "Platinum"]
g = cs.groupby("loyalty_tier").spend.agg(["mean", "std", "count"]).loc[tiers]
g["ci"] = 1.96 * g["std"] / np.sqrt(g["count"])
H, p = stats.kruskal(*[cs[cs.loyalty_tier == t].spend for t in tiers])
fig, ax = plt.subplots(figsize=(7, 4.5))
ax.bar(tiers, g["mean"], yerr=g.ci, capsize=6, color=[C2, GREY, "#C9A227", C1])
for k, t in enumerate(tiers): ax.text(k, 5, f"n={int(g.loc[t,'count'])}", ha="center", color="white", fontsize=9)
ax.set_ylim(0, g["mean"].max() * 1.25); ax.set_ylabel("Average spend per customer (year)")
ax.set_title("Loyalty tier barely changes spend")
save(fig, "06_loyalty_tier_spend.png", f"Error bars = 95% CI overlap heavily. Kruskal p={p:.2f} (not significant).")

# 7 -- RFM ---------------------------------------------------------------------------------
def ntile(s, n, asc=True):
    N = len(s); o = s.rank(method="first", ascending=asc).astype(int) - 1
    base, extra = divmod(N, n); edges = np.cumsum([base + (i < extra) for i in range(n)])
    return np.searchsorted(edges, o.values, side="right") + 1
snap = pd.Timestamp("2025-12-31")
rf = (rev.dropna(subset=["customer_id"]).groupby("customer_id")
        .agg(Rec=("order_date", lambda s: (snap - s.max()).days), Fr=("order_id", "count"), Mo=("net_subtotal", "sum")))
rf["R"], rf["F"], rf["M"] = ntile(rf.Rec, 4, False), ntile(rf.Fr, 4), ntile(rf.Mo, 4)
def seg(r):
    if r.R == 4 and r.F >= 3 and r.M >= 3: return "Champions"
    if r.R <= 2 and r.M >= 3: return "At-Risk\nHigh Spenders"
    if r.F >= 3: return "Loyal Regulars"
    return "Standard"
rf["seg"] = rf.apply(seg, axis=1)
sg = rf.groupby("seg").agg(n=("Mo", "size"), rev=("Mo", "sum"), rec=("Rec", "mean")).sort_values("rev", ascending=False)
fig, ax = plt.subplots(figsize=(8.5, 4.8)); i = np.arange(len(sg)); w = .38
ax.bar(i - w / 2, sg.n / sg.n.sum() * 100, w, color=GREY, label="% of customers")
ax.bar(i + w / 2, sg.rev / sg.rev.sum() * 100, w, color=[C3 if "Risk" in s else C1 for s in sg.index], label="% of revenue")
for k, (s, r) in enumerate(sg.iterrows()): ax.text(k, max(r.n / sg.n.sum(), r.rev / sg.rev.sum()) * 100 + 1, f"avg recency\n{r.rec:.0f}d", ha="center", fontsize=8)
ax.set_xticks(i); ax.set_xticklabels(sg.index); ax.set_ylabel("%"); ax.set_ylim(0, 58); ax.legend()
ax.set_title("RFM: At-Risk High Spenders hold ~27% of revenue and are slipping away")
save(fig, "07_rfm_segments.png", "At-Risk = high spend but last purchase ~60 days ago: the most valuable win-back target.")

# 8 -- hourly distribution (anomaly) ------------------------------------------------------
hr = orders.order_datetime.dt.hour.value_counts().sort_index()
chi, p = stats.chisquare(hr.values)
fig, ax = plt.subplots(figsize=(9, 4.2))
ax.bar(hr.index, hr.values, color=[C3 if h < 6 else C1 for h in hr.index]); ax.axhline(hr.mean(), color="black", ls="--", lw=1)
ax.set_xlabel("Hour of day"); ax.set_ylabel("Orders"); ax.set_xticks(range(0, 24)); ax.set_ylim(0, hr.max() * 1.2)
ax.set_title("Orders are flat across 24 hours - unrealistic for retail")
save(fig, "08_hourly_orders_anomaly.png", f"Chi-square vs uniform p={p:.2f}. Red = midnight-6am ({(orders.order_datetime.dt.hour<6).mean():.0%} of orders). Timestamps are unreliable.")

# 9 -- inventory cover vs lead time -------------------------------------------------------
rate = ri.groupby(["store_id", "product_id"]).quantity.sum().div(365).rename("d").reset_index()
dos = inv.merge(rate, on=["store_id", "product_id"]).merge(prod[["product_id", "supplier_id"]], on="product_id") \
         .merge(sup[["supplier_id", "lead_time_days"]], on="supplier_id")
dos["cover"] = dos.stock_on_hand / dos.d
fig, ax = plt.subplots(figsize=(9, 4.5))
ax.hist(dos.cover.clip(upper=900), bins=45, color=C1, alpha=.85)
ax.axvspan(0, 9, color=C3, alpha=.35, label="Supplier lead times (3-9 days)")
ax.axvline(dos.cover.median(), color="black", ls="--", label=f"Median cover {dos.cover.median():.0f} days")
ax.set_xlabel("Days of cover (stock / avg daily sales)"); ax.set_ylabel("Store x SKU lines"); ax.legend()
ax.set_title("Stock cover vs lead time: stock and sales are on different scales")
save(fig, "09_inventory_cover.png", "Only 2 lines are at real risk, yet median cover is ~11 months -> sales table looks like a sample vs full inventory.")

# 10 -- product Pareto ---------------------------------------------------------------------
pp = ri.groupby("product_name").line_net_amount.sum().sort_values(ascending=False)
cum = pp.cumsum() / pp.sum() * 100
fig, ax = plt.subplots(figsize=(9, 4.5))
ax.plot(np.arange(1, len(cum) + 1) / len(cum) * 100, cum.values, color=C1, lw=2.5, label="Actual")
ax.plot([0, 100], [0, 100], color=GREY, ls="--", label="Perfect equality")
n80 = int((cum < 80).sum() + 1); ax.scatter([n80 / len(cum) * 100], [80], color=C3, zorder=3)
ax.annotate(f"{n80} of {len(cum)} SKUs\n= 80% of revenue", (n80 / len(cum) * 100, 80), xytext=(15, 55), arrowprops=dict(arrowstyle="->"))
ax.set_xlabel("% of SKUs (best first)"); ax.set_ylabel("Cumulative % of revenue"); ax.legend(loc="lower right")
ax.set_title("Product revenue is evenly spread (weak Pareto effect)")
save(fig, "10_product_pareto.png", "Unlike typical retail, there is no 'long tail' to prune: the range is broadly balanced.")

# 11 -- weekday: daily revenue distribution -----------------------------------------------
dly = rev.groupby("order_date").net_subtotal.sum().reset_index(); dly["dow"] = dly.order_date.dt.dayofweek
names = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
F, p = stats.f_oneway(*[dly[dly.dow == d].net_subtotal for d in range(7)])
fig, ax = plt.subplots(figsize=(8, 4.5))
bp = ax.boxplot([dly[dly.dow == d].net_subtotal for d in range(7)], patch_artist=True, medianprops=dict(color="black"))
ax.set_xticklabels(names)
for b in bp["boxes"]: b.set_facecolor(C1); b.set_alpha(.6)
ax.set_ylabel("Daily net revenue"); ax.set_title("No peak day: weekday differences are noise")
save(fig, "11_weekday_distribution.png", f"ANOVA p={p:.2f} (not significant). Day-to-day variation dwarfs weekday effect.")

# 12 -- refund/cancel rates by channel -----------------------------------------------------
oc = orders.groupby(["order_channel", "order_status"]).size().unstack(fill_value=0)
rate_df = oc.div(oc.sum(axis=1), axis=0).loc[:, ["Refunded", "Cancelled"]] * 100
chi, p, _, _ = stats.chi2_contingency(oc)
fig, ax = plt.subplots(figsize=(7.5, 4.3)); rate_df.plot(kind="bar", ax=ax, color=[C2, C3], rot=0)
ax.set_ylabel("% of orders"); ax.set_xlabel(""); ax.set_title("Refund & cancel rates are the same in every channel")
save(fig, "12_refund_cancel_by_channel.png", f"Chi-square p={p:.2f}: no channel hot-spot. Total leakage ~4.3% of net revenue.")

print(f"\nDone: {len(saved)} charts" + (f" saved in {OUT}" if SAVE else ""))
if not NOSHOW:
    print("Opening chart windows - close them to finish.")
    plt.show()
