#!/usr/bin/env python3
"""
Builds RYStore_Report.html  (one self-contained page: findings + charts + full analysis output)
Run:  python build_report.py        (or just double-click run.bat on Windows)
"""
import os, sys, re, html, base64, subprocess, datetime

BASE = os.path.dirname(os.path.abspath(__file__))
PY = sys.executable
ENV = dict(os.environ, PYTHONIOENCODING="utf-8", MPLBACKEND="Agg")

def run(script, *args):
    p = subprocess.run([PY, os.path.join(BASE, script), *args], cwd=BASE, env=ENV,
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    if p.returncode != 0:
        print(p.stdout[-1500:]); print(p.stderr[-2500:])
        sys.exit(f"\nERROR while running {script} (see message above).")
    return p.stdout

print("1/3  Running analysis ...")
out = run("rystore_analysis.py")
open(os.path.join(BASE, "report.txt"), "w", encoding="utf-8").write(out)
ok = len(re.findall(r"\[OK \]", out)); diff = len(re.findall(r"\[DIFF\]", out))

print("2/3  Building charts ...")
run("rystore_charts.py", "--no-show", "--save")

print("3/3  Assembling HTML report ...")
# ---- executive findings (Part 4) ----
part4 = out.split("PART 4 - EXECUTIVE FINDINGS")[-1]
findings = [re.sub(r"\s+", " ", m).strip() for m in re.findall(r"\n\s*\d+\.\s(.*?)(?=\n\s*\n\s*\d+\.|\n\s*\nAnalysis complete)", part4, flags=re.S)]

# ---- charts with a one-line takeaway ----
CHARTS = [
    ("01_monthly_trend.png", "Revenue is flat", "No significant trend; month-to-month moves follow order volume, not basket size."),
    ("02_store_staff_vs_revenue.png", "Staffing is unrelated to sales", "Stores earn the same revenue with 21 to 71 staff (Spearman p=0.96)."),
    ("03_category_revenue_vs_margin.png", "Biggest category, lowest margin", "Meat & Fish leads revenue and profit but has the lowest margin of all 10 categories."),
    ("04_promotion_lift.png", "Only one promotion proves its lift", "Summer BBQ +11% (p=0.02); the other five show no provable lift."),
    ("05_basket_lift_distribution.png", "Basket 'top pairs' are not real affinities", "Pair lift clusters around 1: popular items co-occur by chance."),
    ("06_loyalty_tier_spend.png", "Loyalty tiers barely change spend", "Confidence intervals overlap; Kruskal p=0.22."),
    ("07_rfm_segments.png", "Win-back target: At-Risk High Spenders", "About 27% of revenue from customers whose last purchase was ~60 days ago."),
    ("08_hourly_orders_anomaly.png", "Data anomaly: flat 24-hour order pattern", "Timestamps look unreliable; do not use them for hourly or staffing analysis."),
    ("09_inventory_cover.png", "Stock and sales are on different scales", "Median cover ~11 months vs 3-9 day lead times; validate with full sales data."),
    ("10_product_pareto.png", "No long tail to prune", "Revenue is spread evenly across the range."),
    ("11_weekday_distribution.png", "No peak day of the week", "Weekday differences are noise (ANOVA p=0.86)."),
    ("12_refund_cancel_by_channel.png", "Refund and cancel rates are uniform", "No channel hot-spot; total leakage about 4.3% of net revenue."),
]
cards = []
for fn, title, cap in CHARTS:
    path = os.path.join(BASE, "charts", fn)
    if not os.path.exists(path):
        continue
    b64 = base64.b64encode(open(path, "rb").read()).decode()
    cards.append(f'<figure><h3>{html.escape(title)}</h3><img src="data:image/png;base64,{b64}" alt="{html.escape(title)}">'
                 f'<figcaption>{html.escape(cap)}</figcaption></figure>')

kpi = {}
for label, pat in [("Net revenue", r"Net revenue \(ex VAT, completed\)\s+([\d,\.]+)"), ("Gross profit", r"Gross profit\s+([\d,\.]+)"),
                   ("Gross margin %", r"Gross margin %\s+([\d,\.]+)"), ("Avg order value", r"Average order value\s+([\d,\.]+)")]:
    m = re.search(pat, out); kpi[label] = m.group(1) if m else "-"
kpi_html = "".join(f'<div class="kpi"><span>{html.escape(k)}</span><b>{html.escape(v)}</b></div>' for k, v in kpi.items())
find_html = "".join(f"<li>{html.escape(f)}</li>" for f in findings)

page = f"""<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>RYStore - Analysis Report</title>
<style>
:root{{--bg:#f6f7f9;--card:#fff;--tx:#1d2733;--mut:#6b7785;--ac:#2E6F9E;--bd:#e1e5ea}}
@media (prefers-color-scheme:dark){{:root{{--bg:#14181d;--card:#1d242c;--tx:#e8edf2;--mut:#98a4b1;--ac:#6fb1e0;--bd:#2c3640}}}}
body{{margin:0;background:var(--bg);color:var(--tx);font:15px/1.55 -apple-system,Segoe UI,Roboto,Arial,sans-serif}}
.wrap{{max-width:1050px;margin:0 auto;padding:28px 18px 60px}}
h1{{margin:0 0 4px;font-size:28px}} .sub{{color:var(--mut);margin-bottom:22px}}
h2{{margin:34px 0 12px;font-size:20px;border-bottom:2px solid var(--ac);padding-bottom:6px}}
.kpis{{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px}}
.kpi{{background:var(--card);border:1px solid var(--bd);border-radius:10px;padding:14px}}
.kpi span{{display:block;color:var(--mut);font-size:12px;text-transform:uppercase;letter-spacing:.04em}} .kpi b{{font-size:24px;color:var(--ac)}}
ol.f{{padding-left:22px}} ol.f li{{background:var(--card);border:1px solid var(--bd);border-radius:8px;padding:10px 14px;margin:8px 0;list-style-position:inside}}
.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(460px,1fr));gap:16px}}
figure{{margin:0;background:var(--card);border:1px solid var(--bd);border-radius:10px;padding:14px}}
figure h3{{margin:0 0 8px;font-size:15px}} figure img{{width:100%;height:auto;border-radius:6px;background:#fff}}
figcaption{{color:var(--mut);font-size:13px;margin-top:8px}}
details{{background:var(--card);border:1px solid var(--bd);border-radius:10px;padding:10px 14px}} summary{{cursor:pointer;font-weight:600}}
pre{{overflow-x:auto;font:12px/1.4 Consolas,Menlo,monospace;white-space:pre}}
.badge{{display:inline-block;background:var(--ac);color:#fff;border-radius:20px;padding:2px 10px;font-size:12px;margin-left:8px}}
@media (max-width:560px){{.grid{{grid-template-columns:1fr}}}}
</style></head><body><div class="wrap">
<h1>RYStore Data Warehouse - Analysis Report</h1>
<div class="sub">Generated {datetime.datetime.now():%Y-%m-%d %H:%M} &middot; 10,000 orders &middot; 47,512 order lines &middot; 8 stores
<span class="badge">{ok} of {ok+diff} checks match the SQL file</span></div>
<div class="kpis">{kpi_html}</div>
<h2>Executive findings</h2><ol class="f">{find_html}</ol>
<h2>Evidence</h2><div class="grid">{''.join(cards)}</div>
<h2>Full analysis output (all 20 questions + deep dive)</h2>
<details><summary>Click to expand</summary><pre>{html.escape(out)}</pre></details>
</div></body></html>"""
dest = os.path.join(BASE, "RYStore_Report.html")
open(dest, "w", encoding="utf-8").write(page)
print(f"\nDONE -> {dest}")
