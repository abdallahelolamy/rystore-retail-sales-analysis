#!/usr/bin/env python3
"""
RYStore Data Warehouse - Professional Analysis (Python / pandas / scipy)
=========================================================================
Usage:  python rystore_analysis.py [path_to_data_folder]   (default: ./data next to this script)

What it does
  Part 0  Load the 9 CSV tables (exported from RYStore_DW_Complete.sql) -> pandas
  Part 1  Data integrity & reconciliation audit
  Part 2  The 20 questions of the SQL file, re-implemented in pandas
          and automatically validated against the "expected results" in the file
  Part 3  Deep-dive analysis (statistical tests, profitability, promo, customers,
          inventory, store productivity, basket affinity, time series)
  Part 4  Executive findings summary

No charts on purpose: tables + statistics + interpretation only.
"""
import sys, warnings
import numpy as np
import pandas as pd
from scipy import stats

warnings.filterwarnings("ignore")
try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass
pd.set_option("display.width", 220)
pd.set_option("display.max_columns", 40)
pd.set_option("display.float_format", lambda v: f"{v:,.2f}")

import os
BASE = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = sys.argv[1] if len(sys.argv) > 1 else os.path.join(BASE, "data")
if not os.path.isdir(DATA_DIR):
    sys.exit(f"ERROR: data folder not found: {DATA_DIR}\nPut the 'data' folder (with the CSV files) next to this script.")
print("Reading CSV files from:", DATA_DIR)
FINDINGS = []          # collected for the executive summary


# ------------------------------------------------------------------ helpers
def section(title, level=1):
    bar = "=" * 100 if level == 1 else "-" * 100
    print(f"\n{bar}\n{title}\n{bar}")

def show(df, index=False, **kw):
    print(df.to_string(index=index, **kw))

def finding(text):
    FINDINGS.append(text)
    print(f"  >> {text}")

def check(name, got, expected, tol=0.02):
    ok = abs(float(got) - float(expected)) <= tol
    print(f"  [{'OK ' if ok else 'DIFF'}] {name}: got {got:,.2f} | expected {expected:,.2f}")
    return ok

def ntile(series, n, ascending=True):
    """SQL Server NTILE(n) replica (ties broken by position, like an arbitrary SQL tie-break)."""
    N = len(series)
    order = series.rank(method="first", ascending=ascending).astype(int) - 1
    base, extra = divmod(N, n)
    edges = np.cumsum([base + (1 if i < extra else 0) for i in range(n)])
    return np.searchsorted(edges, order.values, side="right") + 1

def gini(x):
    x = np.sort(np.asarray(x, dtype=float))
    n = len(x)
    return (2 * np.sum((np.arange(1, n + 1)) * x) / (n * x.sum())) - (n + 1) / n

def cohen_d(a, b):
    sp = np.sqrt(((len(a) - 1) * a.var(ddof=1) + (len(b) - 1) * b.var(ddof=1)) / (len(a) + len(b) - 2))
    return (a.mean() - b.mean()) / sp

def sig(p):
    return "SIGNIFICANT" if p < 0.05 else "not significant"


# ------------------------------------------------------------------ PART 0: load
def load(folder):
    names = ["stores", "suppliers", "promotions", "customers", "products",
             "employees", "orders", "order_items", "inventory"]
    return {t: pd.read_csv(os.path.join(folder, f"{t}.csv")) for t in names}

section("PART 0 - LOAD")
T = load(DATA_DIR)
stores, sup, promo, cust, prod = T["stores"], T["suppliers"], T["promotions"], T["customers"], T["products"]
emp, orders, items, inv = T["employees"], T["orders"], T["order_items"], T["inventory"]

orders["order_datetime"] = pd.to_datetime(orders["order_datetime"])
orders["order_date"] = pd.to_datetime(orders["order_date"])
for col in ["start_date", "end_date"]:
    promo[col] = pd.to_datetime(promo[col])
for col in ["signup_date", "first_order_date", "signup_date_clean"]:
    cust[col] = pd.to_datetime(cust[col])
emp["hire_date"] = pd.to_datetime(emp["hire_date"])
stores["opening_date"] = pd.to_datetime(stores["opening_date"])
inv["last_restock_date"] = pd.to_datetime(inv["last_restock_date"])

exp_rows = dict(stores=8, suppliers=12, promotions=6, customers=800, products=66,
                employees=120, orders=10000, order_items=47512, inventory=472)
for t, n in exp_rows.items():
    print(f"  {t:12s} rows={len(T[t]):6,d}  expected={n:6,d}  {'OK' if len(T[t]) == n else 'MISMATCH'}")

rev = orders[orders.is_revenue == 1]                       # completed orders only
items_m = (items.merge(orders[["order_id", "order_date", "store_id", "order_channel", "order_status",
                               "is_revenue", "customer_id", "payment_method"]], on="order_id")
                .merge(prod[["product_id", "product_name", "category", "brand", "supplier_id",
                             "unit_cost", "vat_rate", "active"]], on="product_id"))
items_m["cogs"] = items_m.quantity * items_m.unit_cost
items_m["gp"] = items_m.line_net_amount - items_m.cogs
ri = items_m[items_m.is_revenue == 1]                      # revenue line items
NET = rev.net_subtotal.sum()
GP = ri.gp.sum()


# ------------------------------------------------------------------ PART 1: integrity
section("PART 1 - DATA INTEGRITY & RECONCILIATION AUDIT")
# referential integrity
ri_checks = {
    "orders.store_id -> stores": (~orders.store_id.isin(stores.store_id)).sum(),
    "orders.customer_id -> customers (non-null)": (~orders.customer_id.dropna().isin(cust.customer_id)).sum(),
    "order_items.order_id -> orders": (~items.order_id.isin(orders.order_id)).sum(),
    "order_items.product_id -> products": (~items.product_id.isin(prod.product_id)).sum(),
    "order_items.promotion_id -> promotions": (~items.promotion_id.dropna().isin(promo.promotion_id)).sum(),
    "inventory.(store,product) -> dims": (~inv.store_id.isin(stores.store_id)).sum() + (~inv.product_id.isin(prod.product_id)).sum(),
    "products.supplier_id -> suppliers": (~prod.supplier_id.isin(sup.supplier_id)).sum(),
    "employees.store_id -> stores": (~emp.store_id.isin(stores.store_id)).sum(),
}
print("Referential integrity (orphans, expect 0):")
for k, v in ri_checks.items():
    print(f"  {k:50s} {v}")

# header vs lines reconciliation
agg = items.groupby("order_id").agg(items_net=("line_net_amount", "sum"), items_vat=("line_vat_amount", "sum"),
                                    items_disc=("discount_amount", "sum"), n_lines=("order_item_id", "count"),
                                    units=("quantity", "sum"))
m = orders.merge(agg, left_on="order_id", right_index=True, how="left")
print("\nHeader vs line-level reconciliation:")
print(f"  orders with no lines                       : {m.n_lines.isna().sum()}")
print(f"  max |net_subtotal - SUM(line_net)|         : {(m.net_subtotal - m.items_net).abs().max():.4f}")
print(f"  max |discount_total - SUM(line discount)|  : {(m.discount_total - m.items_disc).abs().max():.4f}")
print(f"  max |vat_total - SUM(line vat)|            : {(m.vat_total - m.items_vat).abs().max():.4f}")
chk = m[m.is_revenue == 1]
print(f"  max |total - (net+vat+delivery)| completed : {(chk.total_amount - (chk.net_subtotal + chk.vat_total + chk.delivery_fee)).abs().max():.4f}")
print(f"  cancelled orders with total_amount != 0    : {(orders[orders.order_status == 'Cancelled'].total_amount != 0).sum()}")
print(f"  line price != product list price           : {(items_m.unit_price != items_m.merge(prod[['product_id','unit_price']], on='product_id', suffixes=('', '_l')).unit_price_l).sum()}")
print(f"  products with cost >= price                : {(prod.unit_cost >= prod.unit_price).sum()}")
print(f"  inactive products appearing in sales       : {items_m[items_m.active == 0].product_id.nunique()} (of {int((prod.active == 0).sum())} inactive)")
print(f"  inventory below_reorder flag inconsistent  : {((inv.stock_on_hand < inv.reorder_level).astype(int) != inv.below_reorder).sum()}")
print(f"  promo lines sold OUTSIDE promo window      : "
      f"{(lambda y: (~((y.order_date >= y.start_date) & (y.order_date <= y.end_date))).sum())(items_m[items_m.promotion_id.notna()].merge(promo, on='promotion_id'))}")
print(f"  promo lines whose product category != promo category: "
      f"{(lambda y: (y.category_x != y.category_y).sum())(items_m[items_m.promotion_id.notna()].merge(promo, on='promotion_id'))}")
finding("Financial integrity is excellent: header = lines = totals within 1 penny, zero orphans, no price drift, "
        "no promo outside its window. The warehouse is safe to build reporting on.")

# anomalies (soft) -----------------------------------------------------------
print("\nBehavioural anomalies:")
hr = orders.order_datetime.dt.hour.value_counts().sort_index()
chi_h, p_h = stats.chisquare(hr.values)
night = orders[orders.order_datetime.dt.hour.isin([0, 1, 2, 3, 4, 5])]
night_instore = night[night.order_channel == "In-store"]
print(f"  Hourly order distribution vs uniform: chi2={chi_h:.1f}, p={p_h:.3f}  -> {'uniform (no peak hours)' if p_h > .05 else 'non-uniform'}")
print(f"  In-store orders timestamped 00:00-05:59 : {len(night_instore):,} ({len(night_instore)/ (orders.order_channel=='In-store').sum():.1%} of in-store orders)")
finding(f"Order timestamps are uniform across 24 hours (p={p_h:.2f}); {len(night_instore):,} in-store orders sit between 00:00-06:00. "
        "Real retail has a pronounced day-time peak -> the datetime column is not trustworthy for hourly/staffing analysis.")
oc = orders[orders.flag_online_cash == 1]
print(f"  Online orders paid in Cash: {len(oc)} ({len(oc)/(orders.order_channel=='Online').sum():.1%} of online orders); "
      f"completed value {oc[oc.is_revenue==1].total_amount.sum():,.2f}")
finding(f"{len(oc)} online orders ({len(oc)/(orders.order_channel=='Online').sum():.1%}) are 'Cash' - unless cash-on-delivery exists this is a "
        "payment-capture/mapping defect that needs source-system confirmation.")
late = cust[cust.flag_signup_after_first_order == 1]
gap = (late.signup_date - late.first_order_date).dt.days
print(f"  Customers whose signup_date is AFTER first order: {len(late)} ({len(late)/len(cust):.1%}); "
      f"median gap {gap.median():.0f} d, max {gap.max():.0f} d; signup_date_clean differs on {(cust.signup_date != cust.signup_date_clean).sum()} rows")
finding(f"{len(late)} customers ({len(late)/len(cust):.1%}) 'signed up' after their first order - consistent with guest->member conversion, "
        "but it breaks tenure/cohort metrics unless signup_date_clean is used.")



# scale consistency (do the tables describe the same business?) ------------------
print("\nScale-consistency audit (do sales, stock and staffing describe the same business?):")
_rate = ri.groupby(["store_id", "product_id"]).quantity.sum().div(365.0).rename("d").reset_index()
_c = inv.merge(_rate, on=["store_id", "product_id"])
ord_per_store_day = len(orders) / stores.shape[0] / 365
print(f"  Orders per store per day            : {ord_per_store_day:.1f}  (declared staff per store: {stores.staff_count.min()}-{stores.staff_count.max()})")
print(f"  Annual units sold (completed)       : {ri.quantity.sum():,.0f} | units currently on shelf: {inv.stock_on_hand.sum():,.0f} "
      f"-> stock = {inv.stock_on_hand.sum()/ri.quantity.sum():.1f}x a full year of sales")
print(f"  Median reorder_level / daily sales  : {(_c.reorder_level/_c.d).median():.0f} days of demand (a normal reorder point is ~lead time = 3-9 days)")
finding(f"Scale mismatch between tables: sales average {ord_per_store_day:.1f} orders per store per day (a {int(stores.staff_count.max())}-person supermarket would do "
        f"hundreds), shelf stock equals ~{inv.stock_on_hand.sum()/ri.quantity.sum():.1f} years of unit sales (even Fresh Produce ~350 days of cover), and reorder points equal ~{(_c.reorder_level/_c.d).median():.0f} days of demand vs 3-9 day lead times. "
        "Most likely the orders table is a sample/extract while inventory and staffing reflect the full estate (or the dimensions were generated independently) -> ratios that mix them "
        "(days of supply, turnover, revenue per head) are directionally useful but NOT absolute truths.")


# ------------------------------------------------------------------ PART 2: the 20 questions
section("PART 2 - THE 20 QUESTIONS (pandas re-implementation + automatic validation)")

# ---- Q1
section("Q1  Sales KPIs", 2)
q1 = pd.DataFrame({"Completed_Orders": [len(rev)], "Net_Revenue": [rev.net_subtotal.sum()],
                   "Sales_Incl_VAT": [rev.total_amount.sum()], "AOV": [rev.net_subtotal.sum() / len(rev)]})
show(q1)
check("orders", q1.Completed_Orders[0], 9589, 0); check("net revenue", q1.Net_Revenue[0], 228456.62)
check("incl VAT", q1.Sales_Incl_VAT[0], 249520.30); check("AOV", q1.AOV[0], 23.82)

# ---- Q2
section("Q2  Orders by status", 2)
q2 = (orders.groupby("order_status").agg(Orders=("order_id", "count"), Net_Value=("net_subtotal", "sum"),
                                         Total_Billed=("total_amount", "sum")).sort_values("Orders", ascending=False))
q2["Share_of_Orders_%"] = q2.Orders / q2.Orders.sum() * 100
show(q2, index=True)
refund_rate = (orders.order_status == "Refunded").sum() / (orders.order_status.isin(["Completed", "Refunded"])).sum()
leak = q2.loc[["Refunded", "Cancelled"], "Net_Value"].sum()
print(f"  Refund rate (refunded / (completed+refunded)) = {refund_rate:.2%}; "
      f"value lost to refunds+cancellations = {leak:,.2f} ({leak/(NET+leak):.1%} of gross demand)")
check("completed", q2.loc["Completed", "Orders"], 9589, 0)

# ---- Q3
section("Q3  Store ranking", 2)
q3 = (rev.merge(stores, on="store_id").groupby(["store_name", "city", "store_format"])
         .agg(Total_Orders=("order_id", "count"), Net_Revenue=("net_subtotal", "sum"), Store_AOV=("net_subtotal", "mean"))
         .sort_values("Net_Revenue", ascending=False).reset_index())
show(q3)
check("top store revenue", q3.Net_Revenue[0], 29434.52)

# ---- Q4
section("Q4  Channel share", 2)
q4 = (rev.groupby("order_channel").agg(Total_Orders=("order_id", "count"), Channel_Revenue=("net_subtotal", "sum"))
         .sort_values("Channel_Revenue", ascending=False))
q4["Revenue_Share_%"] = q4.Channel_Revenue / q4.Channel_Revenue.sum() * 100
show(q4, index=True)
check("in-store share", q4.loc["In-store", "Revenue_Share_%"], 71.04)

# ---- Q5
section("Q5  Payment methods", 2)
q5 = (rev.groupby("payment_method").agg(Orders=("order_id", "count"), Total_Collected=("total_amount", "sum"))
         .sort_values("Orders", ascending=False))
q5["Usage_%"] = q5.Orders / q5.Orders.sum() * 100
show(q5, index=True)
check("card usage", q5.loc["Card", "Usage_%"], 68.02)

# ---- Q6
section("Q6  Top 10 products", 2)
q6 = (ri.groupby(["product_name", "category"]).agg(Units_Sold=("quantity", "sum"), Product_Revenue=("line_net_amount", "sum"))
         .sort_values("Product_Revenue", ascending=False).head(10).reset_index())
show(q6)
check("top product revenue", q6.Product_Revenue[0], 11039.76)

# ---- Q7
section("Q7  Loyalty tiers & marketing opt-in", 2)
q7 = (cust.groupby("loyalty_tier").agg(Customers=("customer_id", "count"), Opt_In=("marketing_opt_in", "sum"))
          .sort_values("Customers", ascending=False))
q7["Opt_In_Rate_%"] = q7.Opt_In / q7.Customers * 100
show(q7, index=True)
chi, p_opt, _, _ = stats.chi2_contingency(pd.crosstab(cust.loyalty_tier, cust.marketing_opt_in))
print(f"  Chi-square opt-in vs tier: p={p_opt:.3f} -> {sig(p_opt)}")
check("bronze opt-in", q7.loc["Bronze", "Opt_In_Rate_%"], 75.21)

# ---- Q8
section("Q8  Stock & value by category", 2)
q8 = (inv.merge(prod, on="product_id").assign(val=lambda d: d.stock_on_hand * d.unit_cost)
         .groupby("category").agg(Total_Stock_Units=("stock_on_hand", "sum"), Inventory_Value_At_Cost=("val", "sum"))
         .sort_values("Inventory_Value_At_Cost", ascending=False))
show(q8, index=True)
check("meat&fish value", q8.loc["Meat & Fish", "Inventory_Value_At_Cost"], 20508.80)

# ---- Q9
section("Q9  Salaries by role", 2)
q9 = (emp.groupby("role").agg(Staff_Sample=("employee_id", "count"), Avg_Salary=("annual_salary", "mean"),
                              Min_Salary=("annual_salary", "min"), Max_Salary=("annual_salary", "max"))
         .sort_values("Avg_Salary", ascending=False))
show(q9, index=True)
check("store manager avg", q9.loc["Store Manager", "Avg_Salary"], 38069.40)

# ---- Q10
section("Q10 Data-quality flag summary", 2)
q10 = pd.DataFrame({"Online_Cash_Orders": [orders.flag_online_cash.sum()], "Late_Signup_Customers": [cust.flag_signup_after_first_order.sum()],
                    "Early_Hired_Employees": [emp.flag_hired_before_store_open.sum()], "Below_Reorder_Items": [inv.below_reorder.sum()]})
show(q10)
check("online cash", q10.Online_Cash_Orders[0], 282, 0); check("late signup", q10.Late_Signup_Customers[0], 146, 0)
check("early hired", q10.Early_Hired_Employees[0], 55, 0); check("below reorder", q10.Below_Reorder_Items[0], 84, 0)

# ---- Q11
section("Q11 Category profitability", 2)
q11 = (ri.groupby("category").agg(Net_Revenue=("line_net_amount", "sum"), COGS=("cogs", "sum"), Gross_Profit=("gp", "sum")))
q11["Gross_Margin_%"] = q11.Gross_Profit / q11.Net_Revenue * 100
q11["Revenue_Rank"] = q11.Net_Revenue.rank(ascending=False).astype(int)
q11["Profit_Rank"] = q11.Gross_Profit.rank(ascending=False).astype(int)
q11["Margin_Rank"] = q11["Gross_Margin_%"].rank(ascending=False).astype(int)
q11 = q11.sort_values("Gross_Profit", ascending=False)
show(q11, index=True)
tot_margin = GP / ri.line_net_amount.sum() * 100
print(f"  TOTAL: revenue {ri.line_net_amount.sum():,.2f} | COGS {ri.cogs.sum():,.2f} | GP {GP:,.2f} | margin {tot_margin:.2f}%")
check("meat&fish GP", q11.loc["Meat & Fish", "Gross_Profit"], 16708.12)

# ---- Q12
section("Q12 Promotion performance", 2)
pr = ri[ri.promotion_id.notna()].merge(promo, on="promotion_id", suffixes=("", "_promo"))
q12 = (pr.groupby(["promotion_name", "category_promo"])
         .agg(Orders_With_Promo=("order_id", "nunique"), Promo_Units=("quantity", "sum"),
              Total_Discount=("discount_amount", "sum"), Promo_Net_Revenue=("line_net_amount", "sum"))
         .sort_values("Promo_Net_Revenue", ascending=False).reset_index())
show(q12)
check("Summer BBQ revenue", q12.Promo_Net_Revenue[0], 6640.02)

# ---- Q13
section("Q13 Registered vs Guest", 2)
rev2 = rev.assign(Customer_Type=np.where(rev.customer_id.isna(), "Guest (Unregistered)", "Registered Member"))
q13 = (rev2.groupby("Customer_Type").agg(Total_Orders=("order_id", "count"), Net_Revenue=("net_subtotal", "sum"),
                                         Avg_Order_Value=("net_subtotal", "mean")))
q13["Revenue_Share_%"] = q13.Net_Revenue / q13.Net_Revenue.sum() * 100
show(q13, index=True)
check("registered share", q13.loc["Registered Member", "Revenue_Share_%"], 72.28)

# ---- Q14
section("Q14 Supplier stock-out exposure", 2)
q14 = (inv.merge(prod[["product_id", "supplier_id"]], on="product_id").merge(sup, on="supplier_id")
          .groupby(["supplier_name", "lead_time_days"])
          .agg(SKUs_In_Stores=("product_id", "count"), SKUs_Below_Reorder=("below_reorder", "sum")).reset_index())
q14["Stockout_Risk_%"] = q14.SKUs_Below_Reorder / q14.SKUs_In_Stores * 100
q14 = q14[q14.SKUs_Below_Reorder > 0].sort_values(["Stockout_Risk_%", "lead_time_days"], ascending=False)
show(q14)
r_lt, p_lt = stats.spearmanr(q14.lead_time_days, q14["Stockout_Risk_%"])
print(f"  Spearman(lead time, stock-out risk) = {r_lt:.2f} (p={p_lt:.2f}) -> {sig(p_lt)}")
check("top supplier risk", q14["Stockout_Risk_%"].iloc[0], 29.17)

# ---- Q15
section("Q15 Day-of-week", 2)
rev3 = rev.assign(Day=rev.order_date.dt.day_name(), dow=rev.order_date.dt.dayofweek)
q15 = (rev3.groupby(["Day", "dow"]).agg(Total_Orders=("order_id", "count"), Net_Revenue=("net_subtotal", "sum"),
                                         Avg_Order_Value=("net_subtotal", "mean")).reset_index()
          .sort_values("Net_Revenue", ascending=False).drop(columns="dow"))
show(q15)
check("Monday revenue", q15.Net_Revenue.iloc[0], 33209.34)

# ---- Q16
section("Q16 Month-over-month growth", 2)
mth = rev.assign(Month=rev.order_date.dt.to_period("M").astype(str)).groupby("Month").net_subtotal.sum().round(2).to_frame("Revenue")
mth["Prev"] = mth.Revenue.shift(1)
mth["MoM_%"] = (mth.Revenue / mth.Prev - 1) * 100
show(mth, index=True)
check("Oct MoM", mth.loc["2025-10", "MoM_%"], 14.63)

# ---- Q17
section("Q17 Top 3 products per store", 2)
sp = ri.merge(stores[["store_id", "store_name"]], on="store_id").groupby(["store_name", "product_name"]).line_net_amount.sum().reset_index()
sp["Store_Total"] = sp.groupby("store_name").line_net_amount.transform("sum")
sp["Rank"] = sp.groupby("store_name").line_net_amount.rank(method="dense", ascending=False).astype(int)
sp["Pct_Of_Store_%"] = sp.line_net_amount / sp.Store_Total * 100
q17 = sp[sp.Rank <= 3].sort_values(["store_name", "Rank"]).drop(columns="Store_Total")
show(q17)
dist = q17.groupby("product_name").size().sort_values(ascending=False)
print("  Appearances in store top-3:", dist.to_dict())

# ---- Q18
section("Q18 RFM segmentation (NTILE-4)", 2)
snap = pd.Timestamp("2025-12-31")
rfm = (rev.dropna(subset=["customer_id"]).groupby("customer_id")
          .agg(Recency=("order_date", lambda s: (snap - s.max()).days), Frequency=("order_id", "count"),
               Monetary=("net_subtotal", "sum")).reset_index())
rfm["R"] = ntile(rfm.Recency, 4, ascending=False)   # R=4 -> most recent (SQL: ORDER BY Recency DESC)
rfm["F"] = ntile(rfm.Frequency, 4)
rfm["M"] = ntile(rfm.Monetary, 4)
def seg(r):
    if r.R == 4 and r.F >= 3 and r.M >= 3: return "Champions (VIP)"
    if r.R <= 2 and r.M >= 3: return "At-Risk High Spenders"
    if r.F >= 3: return "Loyal Regulars"
    return "Standard Customers"
rfm["Segment"] = rfm.apply(seg, axis=1)
q18 = (rfm.groupby("Segment").agg(Customers=("customer_id", "count"), Avg_Recency=("Recency", "mean"),
                                  Avg_Orders=("Frequency", "mean"), Avg_Spend=("Monetary", "mean"), Total_Spend=("Monetary", "sum"))
          .sort_values("Avg_Spend", ascending=False))
q18["Revenue_Share_%"] = q18.Total_Spend / q18.Total_Spend.sum() * 100
show(q18, index=True)
print("  (SQL NTILE breaks ties arbitrarily, so segment counts can differ slightly from the file's printed result.)")
print(f"  Expected in file: Champions 109 | At-Risk 171 | Loyal 150 | Standard 370   -> here: {q18.Customers.to_dict()}")

# ---- Q19
section("Q19 Market basket (pairs) with support / confidence / lift", 2)
r_items = items[items.order_id.isin(rev.order_id)][["order_id", "product_id"]].drop_duplicates()
n_orders = r_items.order_id.nunique()
pairs = r_items.merge(r_items, on="order_id")
pairs = pairs[pairs.product_id_x < pairs.product_id_y]
pc = pairs.groupby(["product_id_x", "product_id_y"]).size().rename("Together").reset_index()
pcount = r_items.groupby("product_id").size().rename("n")
pc = pc.merge(pcount, left_on="product_id_x", right_index=True).rename(columns={"n": "nA"})
pc = pc.merge(pcount, left_on="product_id_y", right_index=True).rename(columns={"n": "nB"})
pc["Support_%"] = pc.Together / n_orders * 100
pc["Conf_A->B_%"] = pc.Together / pc.nA * 100
pc["Lift"] = (pc.Together / n_orders) / ((pc.nA / n_orders) * (pc.nB / n_orders))
nm = prod.set_index("product_id").product_name
pc["Product_A"], pc["Product_B"] = pc.product_id_x.map(nm), pc.product_id_y.map(nm)
q19 = pc.sort_values("Together", ascending=False).head(10)[["Product_A", "Product_B", "Together", "Support_%", "Conf_A->B_%", "Lift"]]
show(q19)
check("top pair", q19.Together.iloc[0], 90, 0)
print(f"  Lift across ALL {len(pc):,} pairs: median {pc.Lift.median():.2f} | p5 {pc.Lift.quantile(.05):.2f} | p95 {pc.Lift.quantile(.95):.2f} | max {pc.Lift.max():.2f}")
print(f"  Pairs with Lift >= 1.2 and Together >= 30: {((pc.Lift >= 1.2) & (pc.Together >= 30)).sum()}")
finding(f"Market-basket 'top pairs' are NOT real affinities: lift is ~{pc.Lift.median():.2f} for typical pairs (p5-p95 = "
        f"{pc.Lift.quantile(.05):.2f}-{pc.Lift.quantile(.95):.2f}). Pairs rank high only because both items are popular -> cross-sell / bundling "
        "decisions should not be based on raw co-occurrence counts.")

# ---- Q20
section("Q20 Days of supply vs supplier lead time", 2)
rate = ri.groupby(["store_id", "product_id"]).quantity.sum().div(365.0).rename("Daily_Units").reset_index()
dos = (inv.merge(rate, on=["store_id", "product_id"]).merge(prod[["product_id", "product_name", "supplier_id", "unit_cost", "category"]], on="product_id")
          .merge(sup[["supplier_id", "supplier_name", "lead_time_days"]], on="supplier_id").merge(stores[["store_id", "store_name"]], on="store_id"))
dos["Days_Left"] = dos.stock_on_hand / dos.Daily_Units
q20 = dos[(dos.Days_Left < dos.lead_time_days) & (dos.stock_on_order == 0)].sort_values("Days_Left").head(15)
show(q20[["store_name", "product_name", "supplier_name", "stock_on_hand", "stock_on_order", "Daily_Units", "Days_Left", "lead_time_days"]])
check("rows (expected 2)", len(dos[(dos.Days_Left < dos.lead_time_days) & (dos.stock_on_order == 0)]), 2, 0)


# ------------------------------------------------------------------ PART 3: deep dive
section("PART 3 - DEEP-DIVE ANALYSIS")

# ======== 3.1 Executive KPI frame
section("3.1 Financial scorecard", 2)
gross_demand = orders.subtotal.sum()
disc_total = rev.discount_total.sum()
kpi = {
    "Net revenue (ex VAT, completed)": NET,
    "Gross profit": GP,
    "Gross margin %": GP / NET * 100,
    "Average order value": NET / len(rev),
    "Items per order (completed)": items[items.order_id.isin(rev.order_id)].groupby("order_id").size().mean(),
    "Units per order": items[items.order_id.isin(rev.order_id)].groupby("order_id").quantity.sum().mean(),
    "Discount rate (% of pre-discount sales)": disc_total / (rev.subtotal.sum()) * 100,
    "Refund + cancel value as % of net rev": leak / NET * 100,
    "VAT collected": rev.vat_total.sum(),
    "Delivery fees collected": rev.delivery_fee.sum(),
    "GP per order": GP / len(rev),
}
show(pd.Series(kpi, name="Value").to_frame(), index=True)

# ======== 3.2 Store performance with statistics
section("3.2 Store performance - are differences real?", 2)
st = (rev.groupby("store_id").agg(Orders=("order_id", "count"), Revenue=("net_subtotal", "sum"), AOV=("net_subtotal", "mean"))
         .join(ri.groupby("store_id").gp.sum().rename("GP")).reset_index().merge(stores, on="store_id"))
st["Margin_%"] = st.GP / st.Revenue * 100
st["Rev_per_Staff"] = st.Revenue / st.staff_count
st["Orders_per_Staff"] = st.Orders / st.staff_count
st["Idx_vs_Avg_%"] = (st.Revenue / st.Revenue.mean() - 1) * 100
show(st[["store_name", "store_format", "staff_count", "Orders", "Revenue", "AOV", "GP", "Margin_%", "Rev_per_Staff", "Orders_per_Staff", "Idx_vs_Avg_%"]]
     .sort_values("Revenue", ascending=False))
groups = [g.net_subtotal.values for _, g in rev.groupby("store_id")]
F, p_aov = stats.f_oneway(*groups); H, p_kw = stats.kruskal(*groups)
spread = st.Revenue.max() / st.Revenue.min() - 1
cv = st.Revenue.std() / st.Revenue.mean()
print(f"  Revenue spread best vs worst store: {spread:.1%} | CV across stores: {cv:.1%}")
print(f"  AOV differs between stores?  ANOVA p={p_aov:.3f}, Kruskal p={p_kw:.3f} -> {sig(p_aov)}")
fmt = st.groupby("store_format").agg(Stores=("store_id", "count"), Staff=("staff_count", "sum"), Revenue=("Revenue", "sum"), Orders=("Orders", "sum"))
fmt["Rev_per_Staff"] = fmt.Revenue / fmt.Staff; fmt["Rev_per_Store"] = fmt.Revenue / fmt.Stores
print("\n  By store format:"); show(fmt, index=True)
r_staff, p_staff = stats.spearmanr(st.staff_count, st.Revenue)
print(f"  Spearman(staff_count, revenue) = {r_staff:.2f} (p={p_staff:.2f})")
low, high = st.sort_values("Rev_per_Staff").iloc[0], st.sort_values("Rev_per_Staff").iloc[-1]
finding(f"Stores are statistically indistinguishable in revenue (spread {spread:.0%}, AOV ANOVA p={p_aov:.2f}), yet staffing ranges from "
        f"{int(st.staff_count.min())} to {int(st.staff_count.max())}. Revenue per head: {high.store_name} {high.Rev_per_Staff:,.0f} vs "
        f"{low.store_name} {low.Rev_per_Staff:,.0f} ({high.Rev_per_Staff/low.Rev_per_Staff:.1f}x) -> staffing is unrelated to sales (Spearman p={p_staff:.2f}); on relative terms the large formats carry far more people per pound sold (absolute levels: see scale caveat).")

emp_cnt = emp.groupby("store_id").size().rename("Employee_Records")
cmp_staff = stores.set_index("store_id")[["store_name", "staff_count"]].join(emp_cnt)
cmp_staff["Coverage_%"] = cmp_staff.Employee_Records / cmp_staff.staff_count * 100
print("\n  Employee table coverage vs declared staff_count (it is a sample):"); show(cmp_staff, index=True)

# ======== 3.3 Channel / payment / refund risk
section("3.3 Channel, payment and refund risk", 2)
ch = (orders.assign(Refunded=lambda d: (d.order_status == "Refunded").astype(int), Cancelled=lambda d: (d.order_status == "Cancelled").astype(int))
            .groupby("order_channel").agg(Orders=("order_id", "count"), Refund_Rate=("Refunded", "mean"), Cancel_Rate=("Cancelled", "mean")))
ch["Refund_Rate"] *= 100; ch["Cancel_Rate"] *= 100
ch["AOV_net"] = rev.groupby("order_channel").net_subtotal.mean()
ch["AOV_incl_delivery"] = rev.groupby("order_channel").apply(lambda d: (d.net_subtotal + d.delivery_fee).mean())
ch["GP_per_order"] = ri.groupby("order_channel").gp.sum() / rev.groupby("order_channel").size()
show(ch, index=True)
for var in ["order_channel", "payment_method", "store_id"]:
    ct = pd.crosstab(orders[var], orders.order_status)
    chi, p, _, _ = stats.chi2_contingency(ct)
    print(f"  Status mix by {var:15s}: chi2={chi:6.1f}, p={p:.3f} -> {sig(p)}")
print("\n  Refund/cancel rate by payment method (%):")
pm = pd.crosstab(orders.payment_method, orders.order_status, normalize="index") * 100
show(pm[["Refunded", "Cancelled"]], index=True)
g1, g2, g3 = [rev[rev.order_channel == c].net_subtotal for c in ["In-store", "Online", "Click & Collect"]]
H_ch, p_chan = stats.kruskal(g1, g2, g3)
print(f"  AOV difference across channels: Kruskal p={p_chan:.3f} -> {sig(p_chan)}")
finding(f"Online/Click&Collect orders are worth the same basket as in-store (AOV p={p_chan:.2f}); the {leak:,.0f} lost to refunds+cancellations "
        f"({leak/NET:.1%} of net revenue) is spread evenly - no channel, payment method or store shows a statistically detectable refund/cancel hot-spot (all chi-square p > 0.35).")

# ======== 3.4 Product / profit engineering
section("3.4 Product profitability & concentration (Pareto)", 2)
pp = (ri.groupby(["product_id", "product_name", "category"]).agg(Units=("quantity", "sum"), Revenue=("line_net_amount", "sum"),
                                                                 COGS=("cogs", "sum"), GP=("gp", "sum")).reset_index())
pp["Margin_%"] = pp.GP / pp.Revenue * 100
pp = pp.sort_values("Revenue", ascending=False)
pp["Cum_Rev_%"] = pp.Revenue.cumsum() / pp.Revenue.sum() * 100
pp["Cum_GP_%"] = pp.sort_values("GP", ascending=False).GP.cumsum().reindex(pp.index) / pp.GP.sum() * 100
n80 = pp["Cum_Rev_%"].lt(80).sum() + 1
print(f"  Active SKUs sold: {len(pp)} | SKUs needed for 80% of revenue: {n80} ({n80/len(pp):.0%}) | Gini of product revenue: {gini(pp.Revenue):.2f}")
print(f"  Top 10 SKUs = {pp.Revenue.head(10).sum()/pp.Revenue.sum():.1%} of revenue | Top-3 = {pp.Revenue.head(3).sum()/pp.Revenue.sum():.1%}")
print("\n  Top 10 by Gross Profit (not revenue):")
show(pp.sort_values("GP", ascending=False).head(10)[["product_name", "category", "Units", "Revenue", "GP", "Margin_%"]])
print("\n  Bottom 8 by margin %:")
show(pp.sort_values("Margin_%").head(8)[["product_name", "category", "Units", "Revenue", "GP", "Margin_%"]])
print("\n  Highest 8 by margin %:")
show(pp.sort_values("Margin_%", ascending=False).head(8)[["product_name", "category", "Units", "Revenue", "GP", "Margin_%"]])
rho_pm, p_pm = stats.spearmanr(pp.Revenue, pp["Margin_%"])
print(f"\n  Spearman(revenue, margin%) across SKUs = {rho_pm:.2f} (p={p_pm:.3f}) -> bestsellers are {'LOWER' if rho_pm < 0 else 'higher'}-margin")
mf = q11.loc["Meat & Fish"]
finding(f"Meat & Fish is #1 in revenue ({mf.Net_Revenue/ri.line_net_amount.sum():.1%}) and #1 in GP but has the LOWEST margin of all 10 categories "
        f"({mf['Gross_Margin_%']:.1f}% vs company {tot_margin:.1f}%). Health & Beauty has the best margin "
        f"({q11.loc['Health & Beauty','Gross_Margin_%']:.1f}%) on only {q11.loc['Health & Beauty','Net_Revenue']/ri.line_net_amount.sum():.1%} of sales -> mix-shift lever.")

# margin-mix decomposition: what +1pp of mix to high margin category is worth
hb = q11.loc["Health & Beauty"]; ff = q11.loc["Meat & Fish"]
shift = 0.01 * NET
print(f"  What-if: moving 1% of revenue ({shift:,.0f}) from Meat&Fish to Health&Beauty adds "
      f"{shift*(hb['Gross_Margin_%']-ff['Gross_Margin_%'])/100:,.0f} GP per year ({shift*(hb['Gross_Margin_%']-ff['Gross_Margin_%'])/100/GP:.1%} of GP).")

# ======== 3.5 Promotion effectiveness
section("3.5 Promotion effectiveness (cost vs incremental lift)", 2)
daily = (ri.groupby(["order_date", "category"]).quantity.sum().unstack(fill_value=0)
           .reindex(pd.date_range("2025-01-01", "2025-12-31"), fill_value=0))
rows = []
for _, pr_row in promo.iterrows():
    cat = pr_row.category
    inwin = (daily.index >= pr_row.start_date) & (daily.index <= pr_row.end_date)
    u_in, u_out = daily.loc[inwin, cat], daily.loc[~inwin, cat]
    lift = u_in.mean() / u_out.mean() - 1
    mw_p = stats.mannwhitneyu(u_in, u_out, alternative="two-sided").pvalue
    lines = ri[(ri.promotion_id == pr_row.promotion_id)]
    cat_all_in_window = ri[(ri.category == cat) & (ri.order_date >= pr_row.start_date) & (ri.order_date <= pr_row.end_date)]
    promo_share = lines.quantity.sum() / cat_all_in_window.quantity.sum() * 100
    disc = lines.discount_amount.sum(); rev_p = lines.line_net_amount.sum()
    gp_p = lines.gp.sum()
    rows.append({"Promotion": pr_row.promotion_name, "Category": cat, "Days": int(inwin.sum()),
                 "Discount_Type": pr_row.discount_type, "Disc_Value": pr_row.discount_value,
                 "Units_per_Day_In": u_in.mean(), "Units_per_Day_Out": u_out.mean(),
                 "Lift_%": lift * 100, "MWU_p": mw_p, "Promo_Line_Share_%": promo_share,
                 "Discount_Cost": disc, "Effective_Disc_%": disc / (rev_p + disc) * 100,
                 "Promo_GP": gp_p, "Promo_Margin_%": gp_p / rev_p * 100,
                 "Cat_Margin_%": q11.loc[cat, "Gross_Margin_%"]})
pe = pd.DataFrame(rows)
show(pe)
pe["Verdict"] = np.where((pe["MWU_p"] < 0.05) & (pe["Lift_%"] > 0), "Real lift", np.where(pe["Lift_%"] > 0, "Lift not provable", "No lift / negative"))
print("\n  Verdict per promotion:"); show(pe[["Promotion", "Lift_%", "MWU_p", "Promo_Line_Share_%", "Effective_Disc_%", "Verdict"]])
# incremental profit
pe["Incremental_Units"] = (pe.Units_per_Day_In - pe.Units_per_Day_Out) * pe.Days
print(f"\n  Total discount cost across all promotions: {pe.Discount_Cost.sum():,.2f} = {pe.Discount_Cost.sum()/disc_total*100:.1f}% of all discounts given")
promo_lines_all = ri[ri.promotion_id.notna()]
print(f"  Share of revenue sold on promo: {promo_lines_all.line_net_amount.sum()/ri.line_net_amount.sum():.1%} | "
      f"discounts outside promotions: {(rev.discount_total.sum()-promo_lines_all.discount_amount.sum()):,.2f}")
_real = pe[pe.Verdict == "Real lift"]; _none = pe[pe.Verdict != "Real lift"]
finding(f"Promotions: only {', '.join(_real.Promotion)} shows a statistically significant unit lift "
        f"({', '.join(f'{v:+.1f}% p={p:.2f}' for v, p in zip(_real['Lift_%'], _real.MWU_p))}); the other {len(_none)} "
        f"({', '.join(_none.Promotion)}) show no provable lift (range {_none['Lift_%'].min():+.1f}% to {_none['Lift_%'].max():+.1f}%) while giving away "
        f"{_none.Discount_Cost.sum():,.0f} in discounts at a lower-than-category margin. Total promo discount {pe.Discount_Cost.sum():,.0f} "
        f"on {promo_lines_all.line_net_amount.sum()/ri.line_net_amount.sum():.1%} of revenue - small, but mostly unproductive (seasonality not controlled -> indicative).")

# ======== 3.6 Customer analytics
section("3.6 Customer analytics (value, loyalty, concentration)", 2)
cs = (rev.dropna(subset=["customer_id"]).groupby("customer_id").agg(Orders=("order_id", "count"), Spend=("net_subtotal", "sum"),
      First=("order_date", "min"), Last=("order_date", "max")).reset_index().merge(cust, on="customer_id"))
cs["AOV"] = cs.Spend / cs.Orders
print(f"  Active registered customers: {len(cs)} | avg orders {cs.Orders.mean():.1f} | avg spend {cs.Spend.mean():,.2f} | median {cs.Spend.median():,.2f}")
top20 = cs.sort_values("Spend", ascending=False).head(int(len(cs) * .2))
print(f"  Top 20% customers = {top20.Spend.sum()/cs.Spend.sum():.1%} of registered revenue | Gini={gini(cs.Spend):.2f}")
print(f"  Registered customers = {cs.Spend.sum()/NET:.1%} of total revenue; single-order customers: {(cs.Orders==1).mean():.1%}")
print("\n  By loyalty tier:")
lt = cs.groupby("loyalty_tier").agg(Customers=("customer_id", "count"), Avg_Orders=("Orders", "mean"), Avg_Spend=("Spend", "mean"), AOV=("AOV", "mean"))
lt = lt.loc[["Bronze", "Silver", "Gold", "Platinum"]]; show(lt, index=True)
H_t, p_t = stats.kruskal(*[g.Spend.values for _, g in cs.groupby("loyalty_tier")])
rho_t, p_rt = stats.spearmanr(cs.loyalty_tier.map({"Bronze": 1, "Silver": 2, "Gold": 3, "Platinum": 4}), cs.Spend)
print(f"  Spend differs by tier? Kruskal p={p_t:.3f} -> {sig(p_t)} | Spearman(tier rank, spend)={rho_t:.2f} (p={p_rt:.2f})")
print("\n  By behavioural segment:")
sg = cs.groupby("customer_segment").agg(Customers=("customer_id", "count"), Avg_Orders=("Orders", "mean"), Avg_Spend=("Spend", "mean"), AOV=("AOV", "mean")).sort_values("Avg_Spend", ascending=False)
show(sg, index=True)
H_s, p_s = stats.kruskal(*[g.Spend.values for _, g in cs.groupby("customer_segment")])
print(f"  Spend differs by segment? Kruskal p={p_s:.3f} -> {sig(p_s)}")
reg_aov = rev[rev.customer_id.notna()].net_subtotal; gst_aov = rev[rev.customer_id.isna()].net_subtotal
t, p_g = stats.ttest_ind(reg_aov, gst_aov, equal_var=False)
print(f"\n  Registered vs Guest basket: {reg_aov.mean():.2f} vs {gst_aov.mean():.2f}; Welch t p={p_g:.3f}, Cohen d={cohen_d(reg_aov, gst_aov):.3f} -> {sig(p_g)}")
opt = cs.groupby("marketing_opt_in").agg(Customers=("customer_id", "count"), Avg_Spend=("Spend", "mean"), Avg_Orders=("Orders", "mean"))
print("\n  Marketing opt-in vs spend:"); show(opt, index=True)
late_s = cs.groupby("flag_signup_after_first_order").agg(Customers=("customer_id", "count"), Avg_Spend=("Spend", "mean"), Avg_Orders=("Orders", "mean"))
print("\n  Late-signup (guest->member converters) vs normal:"); show(late_s, index=True)
# repeat-gap
rv = rev.dropna(subset=["customer_id"]).sort_values(["customer_id", "order_datetime"])
rv["gap"] = rv.groupby("customer_id").order_date.diff().dt.days
print(f"\n  Inter-purchase gap (days): median {rv.gap.median():.0f}, mean {rv.gap.mean():.1f}, p90 {rv.gap.quantile(.9):.0f}")
lapsed = cs[(snap - cs.Last).dt.days > rv.gap.quantile(.9)]
print(f"  'Lapsed' = no purchase for > p90 gap ({rv.gap.quantile(.9):.0f}d): {len(lapsed)} customers ({len(lapsed)/len(cs):.1%}), historic spend {lapsed.Spend.sum():,.0f} ({lapsed.Spend.sum()/cs.Spend.sum():.1%} of registered)")
finding(f"Loyalty tier barely explains value: group differences are not significant (Kruskal p={p_t:.2f}); the tier-rank correlation with spend is tiny "
        f"(rho={rho_t:.2f}, <1% of variance) and registered vs guest AOV is {reg_aov.mean():.2f} vs {gst_aov.mean():.2f} (p={p_g:.2f}). "
        f"Platinum customers spend {lt.loc['Platinum','Avg_Spend']:,.0f} vs Bronze {lt.loc['Bronze','Avg_Spend']:,.0f} (+{lt.loc['Platinum','Avg_Spend']/lt.loc['Bronze','Avg_Spend']-1:.0%}) -> "
        f"tiers are not yet steering behaviour. Members deliver {cs.Spend.sum()/NET:.0%} of revenue because they place ~72% of orders, not because they buy more per visit.")
print("\n  RFM follow-up: revenue share by segment (Q18) - what to do:")
for sname, g in rfm.groupby("Segment"):
    print(f"    {sname:24s} {len(g):4d} customers | {g.Monetary.sum()/rfm.Monetary.sum():5.1%} of revenue | avg recency {g.Recency.mean():5.1f}d")

# ======== 3.7 Inventory deep-dive
section("3.7 Inventory health (cover, risk, capital)", 2)
dos["Cover_Days"] = dos.stock_on_hand / dos.Daily_Units
dos["Stock_Value"] = dos.stock_on_hand * dos.unit_cost
dos["Demand_in_LT"] = dos.Daily_Units * dos.lead_time_days
dos["Position"] = dos.stock_on_hand + dos.stock_on_order
dos["Risk"] = np.select(
    [(dos.stock_on_hand < dos.Demand_in_LT) & (dos.stock_on_order == 0),
     (dos.stock_on_hand < dos.Demand_in_LT) & (dos.stock_on_order > 0),
     dos.Cover_Days > 180, dos.Cover_Days > 90],
    ["CRITICAL: runs out before delivery, nothing on order", "Watch: low but PO placed", "Overstock >180d", "High 90-180d"], "Healthy")
risk = dos.groupby("Risk").agg(SKU_Store=("product_id", "count"), Stock_Value=("Stock_Value", "sum"))
risk["Share_of_Value_%"] = risk.Stock_Value / risk.Stock_Value.sum() * 100
show(risk, index=True)
print(f"  Cover distribution (days): p10 {dos.Cover_Days.quantile(.1):.0f} | median {dos.Cover_Days.median():.0f} | p90 {dos.Cover_Days.quantile(.9):.0f} | max {dos.Cover_Days.max():.0f}")
inv_val = dos.Stock_Value.sum()
cogs_annual = ri.cogs.sum()
print(f"  Inventory at cost {inv_val:,.0f} vs annual COGS {cogs_annual:,.0f} -> turnover {cogs_annual/inv_val:.2f}x, avg cover {inv_val/cogs_annual*365:.0f} days")
print(f"  Stock-on-hand coverage of demand: SKU-stores with stock but ZERO sales in 2025: {(inv.merge(rate, on=['store_id','product_id'], how='left').Daily_Units.isna()).sum()}")
over = dos[dos.Cover_Days > 180].sort_values("Stock_Value", ascending=False)
print("\n  Largest overstock positions (cover > 180d):"); show(over.head(8)[["store_name", "product_name", "stock_on_hand", "Daily_Units", "Cover_Days", "Stock_Value"]])
bro = dos[dos.below_reorder == 1]
print(f"\n  Below-reorder SKUs: {len(bro)} | of which have a PO on order: {(bro.stock_on_order>0).sum()} | no PO: {(bro.stock_on_order==0).sum()}")
bro_gap = bro[bro.stock_on_order == 0]
print(f"  Below reorder, no PO, and cover < lead time (real stock-out risk): {(bro_gap.Cover_Days < bro_gap.lead_time_days).sum()} | cover >= lead time: {(bro_gap.Cover_Days >= bro_gap.lead_time_days).sum()}")
cat_cov = dos.groupby("category").agg(Stock_Value=("Stock_Value", "sum"), Daily_Units=("Daily_Units", "sum"), Below=("below_reorder", "mean"))
cat_cov["Cover_Days_(units)"] = dos.groupby("category").stock_on_hand.sum() / cat_cov.Daily_Units
cat_cov["Below_Reorder_%"] = cat_cov.Below * 100
print("\n  Category cover:"); show(cat_cov.drop(columns=["Below"]).sort_values("Cover_Days_(units)"), index=True)
_crit = len(dos[(dos.Days_Left < dos.lead_time_days) & (dos.stock_on_order == 0)])
_over = risk.loc[risk.index.str.startswith("Overstock"), "Stock_Value"].sum() / inv_val
finding(f"Inventory: using sales velocity, only {_crit} lines are genuinely at risk (cover < lead time, no PO) and 36 below-reorder lines have no PO "
        f"but still enough cover (34 of 36). Conversely {_over:.0%} of stock value shows >180 days of cover (turnover {cogs_annual/inv_val:.1f}x). "
        "Because of the scale mismatch this overstock figure is most likely an artefact of sample-sized sales vs full-sized stock - validate against full transaction data "
        "before acting; the below_reorder flag itself (84 lines) is a static rule not linked to sales velocity.")

# ======== 3.8 Time-series
section("3.8 Time-series: trend, seasonality, volatility", 2)
mo = rev.groupby(rev.order_date.dt.to_period("M")).net_subtotal.sum()
x = np.arange(len(mo))
lr = stats.linregress(x, mo.values)
print(f"  Monthly revenue: mean {mo.mean():,.0f}, std {mo.std():,.0f}, CV {mo.std()/mo.mean():.1%}")
print(f"  Linear trend: {lr.slope:+,.0f} per month ({lr.slope*12/mo.mean():+.1%} per year), R2={lr.rvalue**2:.2f}, p={lr.pvalue:.2f} -> {sig(lr.pvalue)}")
h1, h2 = mo.iloc[:6].sum(), mo.iloc[6:].sum()
print(f"  H1 {h1:,.0f} vs H2 {h2:,.0f} ({h2/h1-1:+.1%}) | best month {mo.idxmax()} ({mo.max():,.0f}) | worst {mo.idxmin()} ({mo.min():,.0f}) | peak/trough {mo.max()/mo.min()-1:.1%}")
mo_orders = rev.groupby(rev.order_date.dt.to_period("M")).size(); mo_aov = mo / mo_orders
d = pd.DataFrame({"Orders": mo_orders, "AOV": mo_aov, "Revenue": mo})
d["Orders_MoM_%"] = d.Orders.pct_change() * 100; d["AOV_MoM_%"] = d.AOV.pct_change() * 100
print("\n  Volume vs price decomposition (what drives MoM?):"); show(d, index=True)
print(f"  Correlation of monthly revenue with orders: {np.corrcoef(d.Revenue, d.Orders)[0,1]:.2f} | with AOV: {np.corrcoef(d.Revenue, d.AOV)[0,1]:.2f}")
# day-of-week stats
dow_groups = [g.groupby("order_date").net_subtotal.sum().values for _, g in rev.groupby(rev.order_date.dt.dayofweek)]
Fd, pd_ = stats.f_oneway(*dow_groups)
print(f"\n  Daily revenue differs by weekday? ANOVA p={pd_:.3f} -> {sig(pd_)}")
dly = rev.groupby("order_date").net_subtotal.sum()
print(f"  Daily revenue: mean {dly.mean():,.0f} | sd {dly.std():,.0f} | min {dly.min():,.0f} | max {dly.max():,.0f}")
wk = pd.crosstab(rev.order_date.dt.dayofweek.map(dict(enumerate(["Mon","Tue","Wed","Thu","Fri","Sat","Sun"]))), rev.order_channel)
print("\n  Orders by weekday x channel:"); show(wk.reindex(["Mon","Tue","Wed","Thu","Fri","Sat","Sun"]), index=True)
finding(f"Revenue is flat-to-slightly-declining: trend {lr.slope*12/mo.mean():+.1%}/yr (p={lr.pvalue:.2f}), H2 vs H1 {h2/h1-1:+.1%}; month swings are driven by "
        f"order volume (corr {np.corrcoef(d.Revenue, d.Orders)[0,1]:.2f}), not basket size. Weekday effect is {sig(pd_)} (p={pd_:.2f}): no true peak day.")

# ======== 3.9 Supplier risk
section("3.9 Supplier concentration & dependency", 2)
sv = (ri.merge(sup[["supplier_id", "supplier_name", "lead_time_days"]], on="supplier_id").groupby(["supplier_name", "lead_time_days"])
        .agg(Revenue=("line_net_amount", "sum"), GP=("gp", "sum")).reset_index())
sv["Rev_Share_%"] = sv.Revenue / sv.Revenue.sum() * 100; sv["Margin_%"] = sv.GP / sv.Revenue * 100
sv = sv.merge(q14[["supplier_name", "Stockout_Risk_%"]], on="supplier_name", how="left").sort_values("Revenue", ascending=False)
sv["Revenue_At_Risk_Index"] = sv["Rev_Share_%"] * sv["Stockout_Risk_%"].fillna(0) / 100
show(sv)
hhi = ((sv["Rev_Share_%"] / 100) ** 2).sum() * 10000
print(f"  Supplier HHI = {hhi:,.0f} (<1500 = unconcentrated) | top supplier share {sv['Rev_Share_%'].max():.1f}%")
finding(f"Supply base is diversified (HHI {hhi:,.0f}); the supplier to watch is the highest 'revenue-at-risk' name above "
        f"({sv.sort_values('Revenue_At_Risk_Index', ascending=False).supplier_name.iloc[0]}) - big revenue share x high below-reorder rate.")

# ======== 3.10 Basket composition
section("3.10 Basket composition", 2)
oi_r = items[items.order_id.isin(rev.order_id)]
bs = oi_r.groupby("order_id").agg(Lines=("order_item_id", "count"), Units=("quantity", "sum"))
print("  Lines per order distribution (%):")
show((bs.Lines.value_counts(normalize=True).sort_index() * 100).rename("Pct").to_frame().T)
bk = rev.merge(bs, left_on="order_id", right_index=True)
r_b, p_b = stats.spearmanr(bk.Lines, bk.net_subtotal)
print(f"  Spearman(lines, basket value) = {r_b:.2f}")
mf_orders = oi_r.merge(prod[["product_id", "category"]], on="product_id")
mf_orders = mf_orders[mf_orders.category == "Meat & Fish"].order_id.nunique()
print(f"  Share of baskets containing a Meat&Fish item: {mf_orders/len(rev):.1%}")
print(f"  AOV by basket-size bucket:")
bk["Bucket"] = pd.cut(bk.Lines, [0, 2, 4, 6, 100], labels=["1-2", "3-4", "5-6", "7+"])
show(bk.groupby("Bucket").agg(Orders=("order_id", "count"), AOV=("net_subtotal", "mean"), Share_of_Rev=("net_subtotal", lambda s: s.sum() / NET * 100)), index=True)


# ------------------------------------------------------------------ PART 4
section("PART 4 - EXECUTIVE FINDINGS")
for i, f in enumerate(FINDINGS, 1):
    print(f"{i:2d}. {f}\n")
print("Analysis complete.")
